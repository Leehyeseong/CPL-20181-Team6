This is the original Malolo1 model with added catapult functionality. The catapult is from https://gitorious.org/mavlab/x100/

-Thomas Gubler
