This directory contains header files unique to the
PX4 Flow V1 board using the STM32F427VIT7 Rev_C silicon (no PB12 silicon bug, full 2M Flash available)
