#ifdef __PX4_QURT
#include <dspal_types.h>
#endif
